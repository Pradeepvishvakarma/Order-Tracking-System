package com.inventory.management.system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.inventory.management.system.model.Inventory;
import com.inventory.management.system.repository.InventoryRepository;
import com.order.tracking.system.service.event.OrderEvent;

@Service
public class InventoryService {
	@Autowired
	private InventoryRepository inventoryRepository;

	@KafkaListener(topics = "order-placed", groupId = "inventory-group")
    public void handleOrderPlaced(OrderEvent event) {
        System.out.println("Received OrderEvent: " + event); // Log the event being received
        Inventory inventory = inventoryRepository.findByProduct(event.getProduct());
        if (inventory != null) {
            if (inventory.getQuantity() >= event.getQuantity()) {
                inventory.setQuantity(inventory.getQuantity() - event.getQuantity());
                inventoryRepository.save(inventory);
                System.out.println("Order processed successfully. Inventory updated.");
            } else {
                System.out.println("Insufficient stock for product: " + event.getProduct());
            }
        } else {
            System.out.println("Product not found in inventory: " + event.getProduct());
        }
    }
}
