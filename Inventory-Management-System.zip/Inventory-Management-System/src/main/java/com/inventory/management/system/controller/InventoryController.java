package com.inventory.management.system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.inventory.management.system.model.Inventory;
import com.inventory.management.system.repository.InventoryRepository;

import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {
	@Autowired
	private InventoryRepository inventoryRepository;

	@GetMapping("/getAllInventory")
	public List<Inventory> getAllInventory() {
		return inventoryRepository.findAll();
	}

	@GetMapping("/getAllInventoryByProduct/{product}")
	public Inventory getInventoryByProduct(@PathVariable String product) {
		return inventoryRepository.findByProduct(product);
	}

	@PostMapping("/updateInventory")
	public Inventory updateInventory(@RequestBody Inventory inventory) {
		return inventoryRepository.save(inventory);
	}
}
